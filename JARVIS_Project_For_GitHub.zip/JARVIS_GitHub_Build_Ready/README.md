# JARVIS Android Starter

A simple JARVIS-style Android starter app with microphone speech recognition, text-to-speech, and basic commands.

## GitHub Actions

The repository workflow can build a debug APK with Gradle and upload it as an Actions artifact.
