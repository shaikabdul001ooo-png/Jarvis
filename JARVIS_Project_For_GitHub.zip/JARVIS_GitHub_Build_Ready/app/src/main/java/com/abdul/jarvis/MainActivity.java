package com.abdul.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 10;
    private TextView output, status;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        output = findViewById(R.id.output); status = findViewById(R.id.status);
        Button mic = findViewById(R.id.micButton);
        tts = new TextToSpeech(this, r -> { if (r == TextToSpeech.SUCCESS) tts.setLanguage(Locale.US); });
        mic.setOnClickListener(v -> listen());
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 11);
    }

    private void listen() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        status.setText("LISTENING…");
        try { startActivityForResult(i, REQ_SPEECH); } catch (Exception e) { reply("Speech recognition is not available on this phone."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) handle(r.get(0)); else status.setText("ONLINE • READY");
        } else status.setText("ONLINE • READY");
    }

    private void handle(String command) {
        String c = command.toLowerCase(Locale.US);
        if (c.contains("hello") || c.contains("hi") || c.contains("jarvis")) reply("Hello, Captain Abdul. I am JARVIS, ready to assist you.");
        else if (c.contains("time")) reply("The time is " + new SimpleDateFormat("hh:mm a", Locale.US).format(new Date()));
        else if (c.contains("who are you")) reply("I am JARVIS, your Android assistant.");
        else reply("You said: " + command);
    }

    private void reply(String text) {
        output.setText(text); status.setText("ONLINE • READY");
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }
    @Override protected void onDestroy() { if (tts != null) tts.shutdown(); super.onDestroy(); }
}
